from fastapi import FastAPI, Query
import os

app = FastAPI(title="RoqNAS Update Server Reference")

# Map of branches to latest versions & changelogs
RELEASES = {
    "release": {
        "version": "v0.0.5",
        "changelog": "Stable production release containing ZFS and MDADM disk expansion.",
        "download_url": "https://update.roqnas.org/downloads/roqnas-release.tar.gz"
    },
    "beta": {
        "version": "v0.0.6-beta1",
        "changelog": "Beta build testing dynamic multi-link bonding and VLAN segmentation.",
        "download_url": "https://update.roqnas.org/downloads/roqnas-beta.tar.gz"
    },
    "dev": {
        "version": "v0.0.7-dev",
        "changelog": "Bleeding-edge active dev commits containing mDNS time machine enhancements.",
        "download_url": "https://update.roqnas.org/downloads/roqnas-dev.tar.gz"
    }
}

@app.get("/api/version")
def get_version(branch: str = Query("release")):
    # Returns the release details corresponding to requested channel branch (release, beta, dev)
    return RELEASES.get(branch, RELEASES["release"])

if __name__ == "__main__":
    import uvicorn
    # To run this server: python3 update_server_reference.py
    # Access endpoint: http://localhost:9000/api/version?branch=release
    uvicorn.run(app, host="0.0.0.0", port=9000)
